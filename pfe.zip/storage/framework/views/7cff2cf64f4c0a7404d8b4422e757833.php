<html><head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<style type="text/css">
    /* FONTS */
    @media screen {
        @font-face {
          font-family: 'Lato';
          font-style: normal;
          font-weight: 400;
          src: local('Lato Regular'), local('Lato-Regular'), url(https://fonts.gstatic.com/s/lato/v11/qIIYRU-oROkIk8vfvxw6QvesZW2xOQ-xsNqO47m55DA.woff) format('woff');
        }

        @font-face {
          font-family: 'Lato';
          font-style: normal;
          font-weight: 700;
          src: local('Lato Bold'), local('Lato-Bold'), url(https://fonts.gstatic.com/s/lato/v11/qdgUG4U09HnJwhYI-uK18wLUuEpTyoUstqEm5AMlJo4.woff) format('woff');
        }

        @font-face {
          font-family: 'Lato';
          font-style: italic;
          font-weight: 400;
          src: local('Lato Italic'), local('Lato-Italic'), url(https://fonts.gstatic.com/s/lato/v11/RYyZNoeFgb0l7W3Vu1aSWOvvDin1pK8aKteLpeZ5c0A.woff) format('woff');
        }

        @font-face {
          font-family: 'Lato';
          font-style: italic;
          font-weight: 700;
          src: local('Lato Bold Italic'), local('Lato-BoldItalic'), url(https://fonts.gstatic.com/s/lato/v11/HkF_qI1x_noxlxhrhMQYELO3LdcAZYWl9Si6vvxL-qU.woff) format('woff');
        }
    }

    /* CLIENT-SPECIFIC STYLES */
    body, table, td, a { -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
    table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
    img { -ms-interpolation-mode: bicubic; }

    /* RESET STYLES */
    img { border: 0; height: auto; line-height: 100%; outline: none; text-decoration: none; }
    table { border-collapse: collapse !important; }
    body { height: 100% !important; margin: 0 !important; padding: 0 !important; width: 100% !important; }

    /* iOS BLUE LINKS */
    a[x-apple-data-detectors] {
        color: inherit !important;
        text-decoration: none !important;
        font-size: inherit !important;
        font-family: inherit !important;
        font-weight: inherit !important;
        line-height: inherit !important;
    }

    /* MOBILE STYLES */
    @media screen and (max-width:600px){
        h1 {
            font-size: 32px !important;
            line-height: 32px !important;
        }
    }

    /* ANDROID CENTER FIX */
    div[style*="margin: 16px 0;"] { margin: 0 !important; }
</style>
</head>
<body style="background-color: #f3f5f7; margin: 0 !important; padding: 0 !important;">

<!-- HIDDEN PREHEADER TEXT -->
<div style="display: none; font-size: 1px; color: #fefefe; line-height: 1px; font-family: 'Lato', Helvetica, Arial, sans-serif; max-height: 0px; max-width: 0px; opacity: 0; overflow: hidden;">
    We're thrilled to have you here! Get ready to dive into your new account.
</div>

<table width="100%" cellspacing="0" cellpadding="0" border="0">
    <!-- LOGO -->
    <tbody><tr>
        <td bgcolor="#8A78F0" align="center">
            <!--[if (gte mso 9)|(IE)]>
            <table align="center" border="0" cellspacing="0" cellpadding="0" width="600">
            <tr>
            <td align="center" valign="top" width="600">
            <![endif]-->
            <table style="max-width: 600px;" width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody><tr>
                    <td style="padding: 80px 10px 80px 10px;" valign="top" align="center">
                        <a href="http://thetheme.io" target="_blank">
                            <img alt="Logo" src="../imgs/ekritn.png" style="display: block; font-family: 'Lato', Helvetica, Arial, sans-serif; color: #ffffff; font-size: 18px;" border="0">
                        </a>
                    </td>
                </tr>
            </tbody></table>
            <!--[if (gte mso 9)|(IE)]>
            </td>
            </tr>
            </table>
            <![endif]-->
        </td>
    </tr>
    <!-- HERO -->
    <tr>
        <td style="padding: 0px 10px 0px 10px;" bgcolor="#8A78F0" align="center">
            <!--[if (gte mso 9)|(IE)]>
            <table align="center" border="0" cellspacing="0" cellpadding="0" width="600">
            <tr>
            <td align="center" valign="top" width="600">
            <![endif]-->
            <table style="max-width: 600px;" width="100%" cellspacing="0" cellpadding="0" border="0">
                <tbody><tr>
                    <td style="padding: 40px 20px 20px 20px; border-radius: 4px 4px 0px 0px; color: #111111; font-family: 'Lato', Helvetica, Arial, sans-serif; font-size: 48px; font-weight: 400; letter-spacing: 4px; line-height: 48px;" valign="top" bgcolor="#ffffff" align="center">
                      <h1 style="font-size: 42px; font-weight: 400; margin: 0;">Welcome!</h1>
                    </td>
                </tr>
            </tbody></table>
            <!--[if (gte mso 9)|(IE)]>
            </td>
            </tr>
            </table>
            <![endif]-->
        </td>
    </tr>
    <!-- COPY BLOCK -->
    <tr>
        <td style="padding: 0px 10px 0px 10px;" bgcolor="#f4f4f4" align="center">
            <!--[if (gte mso 9)|(IE)]>
            <table align="center" border="0" cellspacing="0" cellpadding="0" width="600">
            <tr>
            <td align="center" valign="top" width="600">
            <![endif]-->
            <table style="max-width: 600px;" width="100%" cellspacing="0" cellpadding="0" border="0">
              <!-- COPY -->
              <tbody><tr>
                <td style="padding: 20px 30px 40px 30px; color: #666666; font-family: 'Lato', Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 25px;" bgcolor="#ffffff" align="left">
                  <p style="margin: 0;">Thank you for signing up with TheAdmin! We hope you enjoy your time with us. Check your account and update your profile.</p>
                  <p>Your password is <?php echo e($password); ?></p>
                </td>
              </tr>
              <!-- BULLETPROOF BUTTON -->
              <tr>
                <td bgcolor="#ffffff" align="left">
                  <table width="100%" cellspacing="0" cellpadding="0" border="0">
                    <tbody><tr>
                      <td style="padding: 20px 30px 60px 30px;" bgcolor="#ffffff" align="center">
                        <table cellspacing="0" cellpadding="0" border="0">
                          <tbody><tr>
                              <td style="border-radius: 3px;" bgcolor="#8A78F0" align="center"><a href="agency.localhost" target="_blank" style="font-size: 18px; font-family: Helvetica, Arial, sans-serif; color: #ffffff; text-decoration: none; color: #ffffff; text-decoration: none; padding: 12px 50px; border-radius: 2px; display: inline-block;">Go To Dashboard</a></td>
                          </tr>
                        </tbody></table>
                      </td>
                    </tr>
                  </tbody></table>
                </td>
              </tr>
              <!-- COPY -->
              <tr>
                <td style="padding: 0px 30px 20px 30px; color: #666666; font-family: 'Lato', Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 25px;" bgcolor="#ffffff" align="left">
                  <p style="margin: 0;">If you have any questions, just reply to this email—we're always happy to help out.</p>
                </td>
              </tr>
              <!-- COPY -->
              <tr>
                <td style="padding: 0px 30px 40px 30px; border-radius: 0px 0px 4px 4px; color: #666666; font-family: 'Lato', Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 25px;" bgcolor="#ffffff" align="left">
                  <p style="margin: 0;">Cheers,<br>TheThemeio Team</p>
                </td>
              </tr>
            </tbody></table>
            <!--[if (gte mso 9)|(IE)]>
            </td>
            </tr>
            </table>
            <![endif]-->
        </td>
    </tr>
    <!-- SUPPORT CALLOUT -->
    <tr>
        <td style="padding: 30px 10px 0px 10px;" bgcolor="#f4f4f4" align="center">
            <!--[if (gte mso 9)|(IE)]>
            <table align="center" border="0" cellspacing="0" cellpadding="0" width="600">
            <tr>
            <td align="center" valign="top" width="600">
            <![endif]-->
            <table style="max-width: 600px;" width="100%" cellspacing="0" cellpadding="0" border="0">
                <!-- HEADLINE -->
                <tbody><tr>
                  <td style="padding: 30px 30px 30px 30px; border-radius: 4px 4px 4px 4px; color: #666666; font-family: 'Lato', Helvetica, Arial, sans-serif; font-size: 16px; font-weight: 400; line-height: 25px;" bgcolor="#fafafa" align="center">
                    <h2 style="font-size: 16px; font-weight: 400; color: #111111; margin: 0;">Need more help?</h2>
                    <p style="margin: 0; font-size: 14px;"><a href="http://thetheme.io" target="_blank" style="color: #33cabb;">We’re here, ready to talk</a></p>
                  </td>
                </tr>
            </tbody></table>
            <!--[if (gte mso 9)|(IE)]>
            </td>
            </tr>
            </table>
            <![endif]-->
        </td>
    </tr>
    <!-- FOOTER -->
    <tr>
        <td style="padding: 0px 10px 0px 10px;" bgcolor="#f4f4f4" align="center">
            <!--[if (gte mso 9)|(IE)]>
            <table align="center" border="0" cellspacing="0" cellpadding="0" width="600">
            <tr>
            <td align="center" valign="top" width="600">
            <![endif]-->
            <table style="max-width: 600px;" width="100%" cellspacing="0" cellpadding="0" border="0">
              <!-- NAVIGATION -->
              <tbody><tr>
                <td style="padding: 30px 30px 30px 30px; color: #aaaaaa; font-family: 'Lato', Helvetica, Arial, sans-serif; font-size: 12px; font-weight: 400; line-height: 18px;" bgcolor="#f4f4f4" align="left">
                  <p style="margin: 0;">
                    <a href="http://thetheme.io" target="_blank" style="color: #999999; font-weight: 700;">Dashboard</a> -
                    <a href="http://thetheme.io" target="_blank" style="color: #999999; font-weight: 700;">Billing</a> -
                    <a href="http://thetheme.io" target="_blank" style="color: #999999; font-weight: 700;">Help</a>
                  </p>
                </td>
              </tr>
              <!-- PERMISSION REMINDER -->
              <tr>
                <td style="padding: 0px 30px 30px 30px; color: #aaaaaa; font-family: 'Lato', Helvetica, Arial, sans-serif; font-size: 12px; font-weight: 400; line-height: 18px;" bgcolor="#f4f4f4" align="left">
                  <p style="margin: 0;">You received this email because you just signed up for a new account. If it looks weird, <a href="http://thetheme.io" target="_blank" style="color: #999999; font-weight: 700;">view it in your browser</a>.</p>
                </td>
              </tr>
              <!-- UNSUBSCRIBE -->
              <tr>
                <td style="padding: 0px 30px 30px 30px; color: #aaaaaa; font-family: 'Lato', Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 400; line-height: 18px;" bgcolor="#f4f4f4" align="left">
                  <p style="margin: 0;">If these emails get annoying, please feel free to <a href="http://thetheme.io" target="_blank" style="color: #999999; font-weight: 700;">unsubscribe</a>.</p>
                </td>
              </tr>
              <!-- ADDRESS -->
              <tr>
                <td style="padding: 0px 30px 30px 30px; color: #aaaaaa; font-family: 'Lato', Helvetica, Arial, sans-serif; font-size: 12px; font-weight: 400; line-height: 18px;" bgcolor="#f4f4f4" align="left">
                  <p style="margin: 0;">TheTheme - 1234 Main Street - Anywhere, MA - 56789</p>
                </td>
              </tr>
            </tbody></table>
            <!--[if (gte mso 9)|(IE)]>
            </td>
            </tr>
            </table>
            <![endif]-->
        </td>
    </tr>
</tbody></table>



</body></html><?php /**PATH C:\Users\Baaha\OneDrive\Bureau\tays\resources\views/Emails/agencyConfirm.blade.php ENDPATH**/ ?>