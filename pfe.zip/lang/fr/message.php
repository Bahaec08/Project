<?php

  return [
    'welcome' => 'Bonjour !'
  ];

?>